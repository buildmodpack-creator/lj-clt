# UtilMod (Fabric 1.21.4)
- Fast Use / Fast Break (không delay đặt block, đào nhanh)
- Scaffold: tự đặt block trên đầu + dưới chân, chỉ đặt vào mặt block hợp lệ (tránh ghost block), anti-void
- GUI: Right Shift. Keybind đổi trong Options > Controls > UtilMod.
Build: push lên GitHub -> tab Actions -> tải utilmod-jar. Hoặc local: `gradle build`.
Cách dùng scaffold: xây trước cột 4 block làm điểm tựa, cầm block, bật Scaffold rồi giữ W.
