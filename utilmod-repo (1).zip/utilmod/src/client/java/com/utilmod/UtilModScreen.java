package com.utilmod;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class UtilModScreen extends Screen {
    public UtilModScreen() { super(Text.literal("UtilMod")); }

    @Override protected void init() {
        int x = width / 2 - 205, x2 = width / 2 + 5, y = height / 2 - 95;
        toggle(x, y,       "Đặt nhanh (Fast Use)",   () -> Config.fastUse,    v -> Config.fastUse = v);
        toggle(x, y + 24,  "Đào nhanh", () -> Config.fastBreak,  v -> Config.fastBreak = v);
        toggle(x, y + 48,  "Đặt block trên không",   () -> Config.scaffold,   v -> Config.scaffold = v);
        toggle(x, y + 72,  "Block trên đầu", () -> Config.placeAbove, v -> Config.placeAbove = v);
        toggle(x, y + 96,  "Block dưới chân", () -> Config.placeBelow, v -> Config.placeBelow = v);
        toggle(x, y + 120, "Chống rớt void",  () -> Config.antiVoid,   v -> Config.antiVoid = v);
        toggle(x2, y, "Fix lag (gộp + FPS)", () -> Config.fixLag, v -> Config.fixLag = v);
        toggle(x2, y + 120, "Bridge an toàn (chỉ dưới chân + shift)", () -> Config.safeBridge, v -> Config.safeBridge = v);
        toggle(x2, y + 144, "Gỡ giới hạn 60 FPS", () -> Config.unlockFps, v -> Config.unlockFps = v);
        toggle(x2, y + 168, "Ẩn block/đồ rơi (drop)", () -> Config.hideDrops, v -> Config.hideDrops = v);
        toggle(x2, y + 72, "Tự shift ở mép", () -> Config.edgeSneak, v -> Config.edgeSneak = v);
        toggle(x2, y + 96, "Cột 4 block phía trước", () -> Config.frontColumn, v -> Config.frontColumn = v);
        toggle(x2, y + 24, "Ẩn phần dưới đất", () -> Config.hideUnderground, v -> {
            Config.hideUnderground = v;
            if (client != null && client.worldRenderer != null) client.worldRenderer.reload();
        });
        addDrawableChild(ButtonWidget.builder(Text.literal("Độ sâu giữ lại: " + Config.underDepth), b -> {
            Config.underDepth = Config.underDepth % 10 + 1;
            b.setMessage(Text.literal("Độ sâu giữ lại: " + Config.underDepth));
            if (Config.hideUnderground && client != null) client.worldRenderer.reload();
        }).dimensions(x2, y + 48, 200, 20).build());
        toggle(x, y + 168, "Legit (chống ban)", () -> Config.legit, v -> Config.legit = v);
        addDrawableChild(ButtonWidget.builder(Text.literal("Block mỗi tick: " + Config.placesPerTick), b -> {
            Config.placesPerTick = Config.placesPerTick % 4 + 1;
            b.setMessage(Text.literal("Block mỗi tick: " + Config.placesPerTick));
        }).dimensions(x, y + 144, 200, 20).build());
    }
    private void toggle(int x, int y, String name, BooleanSupplier get, Consumer<Boolean> set) {
        addDrawableChild(ButtonWidget.builder(label(name, get.getAsBoolean()), b -> {
            set.accept(!get.getAsBoolean());
            b.setMessage(label(name, get.getAsBoolean()));
        }).dimensions(x, y, 200, 20).build());
    }
    private Text label(String n, boolean on) { return Text.literal(n + ": " + (on ? "§aBẬT" : "§cTẮT")); }
    @Override public void render(DrawContext c, int mx, int my, float d) {
        super.render(c, mx, my, d);
        c.drawCenteredTextWithShadow(textRenderer, "UtilMod", width / 2, height / 2 - 100, 0xFFFFFF);
    }
}
