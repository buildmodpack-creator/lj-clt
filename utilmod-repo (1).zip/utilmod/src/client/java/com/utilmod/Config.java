package com.utilmod;
public class Config {
    public static boolean fastUse = false;
    public static boolean fastBreak = false;
    public static boolean scaffold = false;
    public static boolean placeAbove = true;   // block on head
    public static boolean placeBelow = true;   // block under feet
    public static boolean antiVoid = true;
    public static boolean legit = true;        // anti-ban: rotation + random delay + short reach
    public static int placesPerTick = 2;       // fast place
}
