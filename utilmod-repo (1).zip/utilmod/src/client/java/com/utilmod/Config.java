package com.utilmod;
import net.fabricmc.loader.api.FabricLoader;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
public class Config {
    public static boolean fastUse = false;
    public static boolean fastBreak = false;
    public static boolean scaffold = false;
    public static boolean placeAbove = false;   // block on head
    public static boolean placeBelow = true;   // block under feet
    public static boolean antiVoid = true;
    public static boolean fixLag = false;        // merge stacked entities, unlock fps, lighter render
    public static boolean hideUnderground = false;
    public static int underDepth = 4;            // blocks kept below the surface
    public static boolean edgeSneak = true;     // auto shift at the edge
    public static boolean frontColumn = false;  // build 4-block column in front
    public static boolean safeBridge = true;    // ONLY block below + shift at edge, slow humanized timing
    public static boolean unlockFps = true;     // remove 60 fps cap
    public static boolean hideDrops = false;    // hide dropped items
    public static boolean autoTool = true;      // pick best tool while mining
    public static boolean autoToolInv = true;   // also pull a better tool from inventory
    public static boolean realRotation = false; // rotate the real camera when placing (Hypixel-friendlier)
    public static boolean autoSafeBed = false;  // wall in the nearest bed with blocks
    public static boolean legitEdge = false;     // smooth look at the edge, place only once aimed
    public static boolean legit = true;        // anti-ban: rotation + random delay + short reach
    public static int placesPerTick = 2;       // fast place

    static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("lj.properties"); }
    public static void save() {
        try {
            Properties pr = new Properties();
            for (Field f : Config.class.getDeclaredFields()) {
                if (!Modifier.isStatic(f.getModifiers())) continue;
                if (f.getType() == boolean.class || f.getType() == int.class) pr.setProperty(f.getName(), String.valueOf(f.get(null)));
            }
            try (var o = Files.newOutputStream(file())) { pr.store(o, "LJ settings"); }
        } catch (Exception ignored) {}
    }
    public static void load() {
        try {
            if (!Files.exists(file())) return;
            Properties pr = new Properties();
            try (var i = Files.newInputStream(file())) { pr.load(i); }
            for (Field f : Config.class.getDeclaredFields()) {
                if (!Modifier.isStatic(f.getModifiers())) continue;
                String v = pr.getProperty(f.getName());
                if (v == null) continue;
                if (f.getType() == boolean.class) f.setBoolean(null, Boolean.parseBoolean(v));
                else if (f.getType() == int.class) f.setInt(null, Integer.parseInt(v));
            }
        } catch (Exception ignored) {}
    }
}
