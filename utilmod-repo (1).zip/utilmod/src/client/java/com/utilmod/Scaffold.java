package com.utilmod;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import java.util.concurrent.ThreadLocalRandom;

public class Scaffold {
    private static int placed;
    private static int cooldown;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player; ClientWorld w = mc.world;
        if (p == null || w == null || mc.interactionManager == null) return;
        if (!selectBlock(p)) return;
        placed = 0;
        if (Config.legit && cooldown-- > 0) return;
        BlockPos feet = p.getBlockPos();
        if (Config.placeBelow) {
            tryPlace(mc, feet.down());
            // anti-void: while falling, try to build a chain below us
            if (Config.antiVoid && p.getVelocity().y < -0.1 && !p.isOnGround()) {
                for (int dy = 2; dy <= 4; dy++) tryPlace(mc, feet.down(dy));
            }
        }
        if (Config.placeAbove) tryPlace(mc, feet.up(2));
    }

    private static boolean selectBlock(ClientPlayerEntity p) {
        ItemStack held = p.getMainHandStack();
        if (isGood(held)) return true;
        for (int i = 0; i < 9; i++) {
            if (isGood(p.getInventory().getStack(i))) { p.getInventory().setSelectedSlot(i); return true; }
        }
        return false;
    }
    private static boolean isGood(ItemStack s) {
        return !s.isEmpty() && s.getItem() instanceof BlockItem bi
            && bi.getBlock().getDefaultState().isFullCube(null, BlockPos.ORIGIN) ;
    }

    /** Places only against a real solid neighbour with the correct face -> no ghost blocks. */
    private static void tryPlace(MinecraftClient mc, BlockPos pos) {
        if (placed >= (Config.legit ? 1 : Config.placesPerTick)) return;
        ClientPlayerEntity p = mc.player; ClientWorld w = mc.world;
        if (!w.getBlockState(pos).isReplaceable()) return;
        if (p.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos)) > (Config.legit ? 3.0 * 3.0 : 4.0 * 4.0)) return;
        // don't place inside our own hitbox
        if (p.getBoundingBox().intersects(new net.minecraft.util.math.Box(pos))) return;
        for (Direction d : Direction.values()) {
            BlockPos n = pos.offset(d);
            BlockState ns = w.getBlockState(n);
            if (ns.isAir() || ns.isReplaceable() || !ns.isSolidBlock(w, n)) continue;
            Direction face = d.getOpposite();
            ThreadLocalRandom r = ThreadLocalRandom.current();
            Vec3d hitPos = Vec3d.ofCenter(n).add(Vec3d.of(face.getVector()).multiply(0.5));
            if (Config.legit) {
                // small random offset on the face, then look at it (server-side rotation) before placing
                Vec3d off = new Vec3d(face.getAxis() == Direction.Axis.X ? 0 : r.nextDouble(-0.3, 0.3),
                                      face.getAxis() == Direction.Axis.Y ? 0 : r.nextDouble(-0.3, 0.3),
                                      face.getAxis() == Direction.Axis.Z ? 0 : r.nextDouble(-0.3, 0.3));
                hitPos = hitPos.add(off);
                Vec3d eye = p.getEyePos(), dv = hitPos.subtract(eye);
                float yaw = (float) (Math.toDegrees(Math.atan2(dv.z, dv.x)) - 90.0);
                float pitch = (float) -Math.toDegrees(Math.atan2(dv.y, Math.sqrt(dv.x * dv.x + dv.z * dv.z)));
                p.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, p.isOnGround(), p.horizontalCollision));
                cooldown = r.nextInt(0, 3); // random 0-2 tick gap
            }
            BlockHitResult hit = new BlockHitResult(hitPos, face, n, false);
            mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
            p.swingHand(Hand.MAIN_HAND);
            placed++;
            return;
        }
    }
}
