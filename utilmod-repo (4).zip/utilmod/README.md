# UtilMod (Fabric 1.21.4)
- Fast Use / Fast Break (không delay đặt block, đào nhanh)
- Scaffold: tự đặt block trên đầu + dưới chân, chỉ đặt vào mặt block hợp lệ (tránh ghost block), anti-void
- GUI: Right Shift. Keybind đổi trong Options > Controls > UtilMod.
Build: push lên GitHub -> tab Actions -> tải utilmod-jar. Hoặc local: `gradle build`.
Cách dùng scaffold: xây trước cột 4 block làm điểm tựa, cầm block, bật Scaffold rồi giữ W.

## Fix Lag (client-side)
- Gộp render entity trùng vị trí (Wind Charge, Armor Stand, Minecart, Item, XP orb), ẩn entity > 64 block.
- Mở khoá FPS (unlimited, tắt vsync), tắt particles/shadow/cloud/biome blend, gamma sáng.
- Hide underground: không render block sâu hơn N ô dưới mặt đất (ESP vẫn thấy vì đọc dữ liệu world).
