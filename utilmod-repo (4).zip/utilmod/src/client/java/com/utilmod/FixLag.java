package com.utilmod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.projectile.AbstractWindChargeEntity;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import java.util.HashSet;
import java.util.Set;

/** Client-side only: merges stacked entities visually + lightens rendering. */
public class FixLag {
    private static volatile Set<Integer> hidden = new HashSet<>();
    private static boolean wasOn = false;
    private static int ticks = 0;

    private record Key(EntityType<?> t, int x, int y, int z) {}

    static boolean mergeable(Entity e) {
        return e instanceof AbstractWindChargeEntity || e instanceof ArmorStandEntity
            || e instanceof AbstractMinecartEntity || e instanceof ItemEntity || e instanceof ExperienceOrbEntity;
    }

    public static boolean shouldHide(Entity e) {
        if (!Config.fixLag || !mergeable(e)) return false;
        return hidden.contains(e.getId());
    }

    /** true = skip rendering this block in the chunk mesh (ESP is unaffected, it reads world data). */
    public static boolean hideBlock(BlockPos pos) {
        if (!Config.hideUnderground) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null || mc.world.getDimension().hasCeiling()) return false;
        int top = mc.world.getTopY(Heightmap.Type.WORLD_SURFACE, pos.getX(), pos.getZ());
        int pTop = mc.world.getTopY(Heightmap.Type.WORLD_SURFACE, mc.player.getBlockX(), mc.player.getBlockZ());
        if (mc.player.getY() < pTop - 2) return false; // player is underground: show everything
        return pos.getY() < top - Config.underDepth;
    }

    public static void tick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) return;
        if (Config.fixLag != wasOn) { wasOn = Config.fixLag; if (wasOn) applyOptions(mc); }
        if (!Config.fixLag) { if (!hidden.isEmpty()) hidden = new HashSet<>(); return; }
        if (++ticks % 100 == 0) applyOptions(mc);
        if (ticks % 2 != 0) return;
        Set<Key> seen = new HashSet<>();
        Set<Integer> h = new HashSet<>();
        for (Entity e : mc.world.getEntities()) {
            if (!mergeable(e)) continue;
            if (e.squaredDistanceTo(mc.player) > 64 * 64) { h.add(e.getId()); continue; }
            Key k = new Key(e.getType(), (int) Math.floor(e.getX() * 2), (int) Math.floor(e.getY() * 2), (int) Math.floor(e.getZ() * 2));
            if (!seen.add(k)) h.add(e.getId());
        }
        hidden = h;
    }

    static void applyOptions(MinecraftClient mc) {
        var o = mc.options;
        o.getMaxFps().setValue(260);              // 260 = unlimited
        o.getEnableVsync().setValue(false);
        o.getEntityShadows().setValue(false);
        o.getBiomeBlendRadius().setValue(0);      // faster chunk meshing
        o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        o.getGamma().setValue(1.0);               // brighter world
    }
}
