package com.utilmod;
import com.utilmod.mixin.InteractionManagerAccessor;
import com.utilmod.mixin.MinecraftClientAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class UtilModClient implements ClientModInitializer {
    static KeyBinding gui, fast, scaf;
    @Override public void onInitializeClient() {
        net.fabricmc.loader.api.FabricLoader.getInstance().getModContainer("utilmod").ifPresent(mc ->
            net.fabricmc.fabric.api.resource.ResourceManagerHelper.registerBuiltinResourcePack(
                net.minecraft.util.Identifier.of("utilmod", "utilmod_bright"), mc,
                net.fabricmc.fabric.api.resource.ResourcePackActivationType.ALWAYS_ENABLED));
        gui  = reg("key.utilmod.gui", GLFW.GLFW_KEY_RIGHT_SHIFT);
        fast = reg("key.utilmod.fastuse", GLFW.GLFW_KEY_UNKNOWN);
        scaf = reg("key.utilmod.scaffold", GLFW.GLFW_KEY_UNKNOWN);
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (gui.wasPressed()) mc.setScreen(new UtilModScreen());
            while (fast.wasPressed()) { boolean v = !(Config.fastUse && Config.fastBreak); Config.fastUse = Config.fastBreak = v; msg(mc, "Fast Use/Break " + (v ? "ON" : "OFF")); }
            while (scaf.wasPressed()) { Config.scaffold = !Config.scaffold; msg(mc, "Scaffold " + (Config.scaffold ? "ON" : "OFF")); }
            if (mc.player == null || mc.world == null) return;
            if (Config.fastUse) ((MinecraftClientAccessor) mc).utilmod$setItemUseCooldown(0);
            if (Config.fastBreak && mc.interactionManager != null)
                ((InteractionManagerAccessor) mc.interactionManager).utilmod$setBreakCooldown(0);
            if (Config.scaffold) Scaffold.tick(mc);
            FixLag.tick(mc);
        });
    }
    private static KeyBinding reg(String k, int key) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(k, InputUtil.Type.KEYSYM, key, "category.utilmod"));
    }
    private static void msg(net.minecraft.client.MinecraftClient mc, String s) {
        if (mc.player != null) mc.player.sendMessage(Text.literal("[UtilMod] " + s), true);
    }
}
