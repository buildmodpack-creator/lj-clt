package com.utilmod;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/** While you hold attack on a block: pick the fastest tool from hotbar, or swap one in from the inventory. */
public class AutoTool {
    private static int cd;
    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (cd > 0) { cd--; return; }
        if (!mc.options.attackKey.isPressed()) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
        BlockState st = mc.world.getBlockState(hit.getBlockPos());
        if (st.isAir()) return;
        float best = speed(p.getInventory().getStack(p.getInventory().getSelectedSlot()), st);
        int bestHot = -1, bestInv = -1; float bestInvSpeed = best;
        for (int i = 0; i < 9; i++) {
            float s = speed(p.getInventory().getStack(i), st);
            if (s > best) { best = s; bestHot = i; }
        }
        if (bestHot >= 0) { p.getInventory().setSelectedSlot(bestHot); cd = 5; return; }
        if (Config.autoToolInv) {
            for (int i = 9; i < 36; i++) {
                float s = speed(p.getInventory().getStack(i), st);
                if (s > bestInvSpeed + 0.5f) { bestInvSpeed = s; bestInv = i; }
            }
            if (bestInv >= 0) {
                int hot = p.getInventory().getSelectedSlot();
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, bestInv, hot, SlotActionType.SWAP, p);
                cd = 10;
            }
        }
    }
    private static float speed(ItemStack s, BlockState st) { return s.isEmpty() ? 1.0f : s.getMiningSpeedMultiplier(st); }
}
