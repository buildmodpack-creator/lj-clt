package com.utilmod;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class UtilModScreen extends Screen {
    public UtilModScreen() { super(Text.literal("UtilMod")); }

    @Override protected void init() {
        int x = width / 2 - 205, x2 = width / 2 + 5, y = height / 2 - 95;
        toggle(x, y,       "Fast Use",   () -> Config.fastUse,    v -> Config.fastUse = v);
        toggle(x, y + 24,  "Fast Break", () -> Config.fastBreak,  v -> Config.fastBreak = v);
        toggle(x, y + 48,  "Scaffold",   () -> Config.scaffold,   v -> Config.scaffold = v);
        toggle(x, y + 72,  "Block above head", () -> Config.placeAbove, v -> Config.placeAbove = v);
        toggle(x, y + 96,  "Block below feet", () -> Config.placeBelow, v -> Config.placeBelow = v);
        toggle(x, y + 120, "Anti Void",  () -> Config.antiVoid,   v -> Config.antiVoid = v);
        toggle(x2, y, "Fix Lag (merge + FPS)", () -> Config.fixLag, v -> Config.fixLag = v);
        toggle(x2, y + 72, "Edge auto-shift", () -> Config.edgeSneak, v -> Config.edgeSneak = v);
        toggle(x2, y + 96, "Front 4-block column", () -> Config.frontColumn, v -> Config.frontColumn = v);
        toggle(x2, y + 24, "Hide underground", () -> Config.hideUnderground, v -> {
            Config.hideUnderground = v;
            if (client != null && client.worldRenderer != null) client.worldRenderer.reload();
        });
        addDrawableChild(ButtonWidget.builder(Text.literal("Keep depth: " + Config.underDepth), b -> {
            Config.underDepth = Config.underDepth % 10 + 1;
            b.setMessage(Text.literal("Keep depth: " + Config.underDepth));
            if (Config.hideUnderground && client != null) client.worldRenderer.reload();
        }).dimensions(x2, y + 48, 200, 20).build());
        toggle(x, y + 168, "Legit (anti-ban)", () -> Config.legit, v -> Config.legit = v);
        addDrawableChild(ButtonWidget.builder(Text.literal("Places/tick: " + Config.placesPerTick), b -> {
            Config.placesPerTick = Config.placesPerTick % 4 + 1;
            b.setMessage(Text.literal("Places/tick: " + Config.placesPerTick));
        }).dimensions(x, y + 144, 200, 20).build());
    }
    private void toggle(int x, int y, String name, BooleanSupplier get, Consumer<Boolean> set) {
        addDrawableChild(ButtonWidget.builder(label(name, get.getAsBoolean()), b -> {
            set.accept(!get.getAsBoolean());
            b.setMessage(label(name, get.getAsBoolean()));
        }).dimensions(x, y, 200, 20).build());
    }
    private Text label(String n, boolean on) { return Text.literal(n + ": " + (on ? "§aON" : "§cOFF")); }
    @Override public void render(DrawContext c, int mx, int my, float d) {
        super.render(c, mx, my, d);
        c.drawCenteredTextWithShadow(textRenderer, "UtilMod", width / 2, height / 2 - 100, 0xFFFFFF);
    }
}
