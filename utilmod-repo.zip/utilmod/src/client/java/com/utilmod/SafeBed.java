package com.utilmod;
import net.minecraft.block.BedBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import java.util.LinkedHashSet;
import java.util.Set;

/** Defensive: walls in the nearest bed (sides, then a second ring, then the roof) with your own blocks. */
public class SafeBed {
    private static int scan, warn;
    private static BlockPos bed;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player; ClientWorld w = mc.world;
        if (p == null || w == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (scan-- <= 0) { scan = 10; bed = findBed(p, w); }
        if (bed == null) return;
        if (!Scaffold.selectBlock(p)) {
            if (warn-- <= 0) { p.sendMessage(Text.literal("§c⚠ Hết block để bảo vệ giường"), true); warn = 40; }
            return;
        }
        if (Config.legit && Scaffold.cooldown-- > 0) return;
        Scaffold.placed = 0;
        for (BlockPos t : targets(w, bed)) {
            Scaffold.tryPlace(mc, t, 2);
            if (Scaffold.placed > 0) return;
        }
    }

    private static BlockPos findBed(ClientPlayerEntity p, ClientWorld w) {
        BlockPos c = p.getBlockPos(), best = null; double bd = 1e9;
        for (int x = -5; x <= 5; x++) for (int y = -3; y <= 3; y++) for (int z = -5; z <= 5; z++) {
            BlockPos q = c.add(x, y, z);
            if (w.getBlockState(q).getBlock() instanceof BedBlock) {
                double d = q.getSquaredDistance(c);
                if (d < bd) { bd = d; best = q; }
            }
        }
        return best;
    }

    private static Set<BlockPos> targets(ClientWorld w, BlockPos b) {
        Set<BlockPos> parts = new LinkedHashSet<>(); parts.add(b);
        for (Direction d : Direction.Type.HORIZONTAL)
            if (w.getBlockState(b.offset(d)).getBlock() instanceof BedBlock) parts.add(b.offset(d));
        Set<BlockPos> sides = new LinkedHashSet<>();
        for (BlockPos part : parts) for (Direction d : Direction.Type.HORIZONTAL) {
            BlockPos s = part.offset(d);
            if (!parts.contains(s)) sides.add(s);
        }
        Set<BlockPos> out = new LinkedHashSet<>(sides);
        for (BlockPos s : sides) out.add(s.up());
        for (BlockPos part : parts) out.add(part.up());
        return out;
    }
}
