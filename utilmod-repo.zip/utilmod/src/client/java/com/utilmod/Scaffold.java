package com.utilmod;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import java.util.concurrent.ThreadLocalRandom;

public class Scaffold {
    private static int placed, cooldown, warnTimer;
    private static boolean forcedSneak, forcedStop;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player; ClientWorld w = mc.world;
        if (p == null || w == null || mc.interactionManager == null) return;

        // direction we are moving (velocity, else where we look)
        Vec3d v = p.getVelocity();
        double dx, dz;
        if (Math.hypot(v.x, v.z) > 0.03) { double l = Math.hypot(v.x, v.z); dx = v.x / l; dz = v.z / l; }
        else { double r = Math.toRadians(p.getYaw()); dx = -Math.sin(r); dz = Math.cos(r); }
        BlockPos ahead = BlockPos.ofFloored(p.getX() + dx * 0.7, p.getY() - 1, p.getZ() + dz * 0.7);
        BlockPos feet = p.getBlockPos();
        boolean edge = w.getBlockState(ahead).isReplaceable();
        boolean overAir = w.getBlockState(feet.down()).isReplaceable();

        boolean haveBlock = selectBlock(p);
        if (!haveBlock) {
            if (warnTimer-- <= 0) { p.sendMessage(Text.literal("§c⚠ Hết block! Lấy block vào hotbar rồi mới đi tiếp"), true); warnTimer = 20; }
            if (edge || overAir) { hold(mc.options.forwardKey, false); hold(mc.options.sneakKey, true); forcedStop = true; forcedSneak = true; }
            return;
        }
        if (forcedStop) { restore(mc, mc.options.forwardKey); forcedStop = false; }

        // auto shift at the edge (prevents void falls)
        if (Config.edgeSneak) {
            if (edge && p.isOnGround()) { hold(mc.options.sneakKey, true); forcedSneak = true; }
            else if (forcedSneak) { restore(mc, mc.options.sneakKey); forcedSneak = false; }
        } else if (forcedSneak) { restore(mc, mc.options.sneakKey); forcedSneak = false; }

        placed = 0;
        if (Config.legit && cooldown-- > 0) return;

        if (Config.frontColumn) {
            // 4 blocks in front, bottom -> top: below-feet level ... above head
            BlockPos base = BlockPos.ofFloored(p.getX() + dx * 1.0, p.getY(), p.getZ() + dz * 1.0);
            for (int i = -1; i <= 2; i++) tryPlace(mc, base.up(i));
            return;
        }
        if (Config.placeBelow) {
            tryPlace(mc, ahead);
            tryPlace(mc, feet.down());
            if (Config.antiVoid && v.y < -0.1 && !p.isOnGround())
                for (int dy = 2; dy <= 4; dy++) tryPlace(mc, feet.down(dy));
        }
        if (Config.placeAbove) tryPlace(mc, feet.up(2));
    }

    public static void stop(MinecraftClient mc) {
        if (forcedStop) { restore(mc, mc.options.forwardKey); forcedStop = false; }
        if (forcedSneak) { restore(mc, mc.options.sneakKey); forcedSneak = false; }
    }

    private static void hold(KeyBinding k, boolean down) { k.setPressed(down); }
    private static void restore(MinecraftClient mc, KeyBinding k) {
        long h = mc.getWindow().getHandle();
        int code = InputUtil.fromTranslationKey(k.getBoundKeyTranslationKey()).getCode();
        k.setPressed(code >= 0 && InputUtil.isKeyPressed(h, code));
    }

    private static boolean selectBlock(ClientPlayerEntity p) {
        if (isGood(p.getMainHandStack())) return true;
        for (int i = 0; i < 9; i++)
            if (isGood(p.getInventory().getStack(i))) { p.getInventory().setSelectedSlot(i); return true; }
        return false;
    }
    private static boolean isGood(ItemStack s) {
        return !s.isEmpty() && s.getItem() instanceof BlockItem bi
            && bi.getBlock().getDefaultState().isFullCube(null, BlockPos.ORIGIN);
    }

    private static void tryPlace(MinecraftClient mc, BlockPos pos) {
        if (placed >= (Config.legit ? 1 : Config.placesPerTick)) return;
        ClientPlayerEntity p = mc.player; ClientWorld w = mc.world;
        if (!w.getBlockState(pos).isReplaceable()) return;
        if (p.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos)) > (Config.legit ? 9.0 : 16.0)) return;
        if (p.getBoundingBox().intersects(new Box(pos))) return;
        for (Direction d : Direction.values()) {
            BlockPos n = pos.offset(d);
            BlockState ns = w.getBlockState(n);
            if (ns.isAir() || ns.isReplaceable() || !ns.isSolidBlock(w, n)) continue;
            Direction face = d.getOpposite();
            ThreadLocalRandom r = ThreadLocalRandom.current();
            Vec3d hitPos = Vec3d.ofCenter(n).add(Vec3d.of(face.getVector()).multiply(0.5));
            if (Config.legit) {
                Vec3d off = new Vec3d(face.getAxis() == Direction.Axis.X ? 0 : r.nextDouble(-0.3, 0.3),
                                      face.getAxis() == Direction.Axis.Y ? 0 : r.nextDouble(-0.3, 0.3),
                                      face.getAxis() == Direction.Axis.Z ? 0 : r.nextDouble(-0.3, 0.3));
                hitPos = hitPos.add(off);
                Vec3d dv = hitPos.subtract(p.getEyePos());
                float yaw = (float) (Math.toDegrees(Math.atan2(dv.z, dv.x)) - 90.0);
                float pitch = (float) -Math.toDegrees(Math.atan2(dv.y, Math.sqrt(dv.x * dv.x + dv.z * dv.z)));
                p.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, p.isOnGround(), p.horizontalCollision));
                cooldown = r.nextInt(0, 3);
            }
            mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hitPos, face, n, false));
            p.swingHand(Hand.MAIN_HAND);
            placed++;
            return;
        }
    }
}
